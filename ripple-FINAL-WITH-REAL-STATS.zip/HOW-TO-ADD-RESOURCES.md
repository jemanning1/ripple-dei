# How to Add Approved Resources to Ripple

This guide shows you how to add resources that have been approved in the Google Sheet to the live Ripple website.

---

## Step 1: Review Submissions in Google Sheet

1. Open the **"Ripple DEI Submissions"** Google Sheet
2. Look for rows where **Status = "Pending"**
3. Review the submission:
   - Is it high quality?
   - Is it relevant to DEI?
   - Does it add value?
4. If approved, change **Status to "Approved"**
5. Make note of the details you'll need:
   - Resource Type
   - Category
   - Title
   - Description
   - Link (if provided)
   - Submitted By

---

## Step 2: Prepare the Resource Code

You'll need to add a new resource object to the code. Here's the template:

```javascript
{
    id: [NEXT_NUMBER],
    category: '[CATEGORY]',
    title: '[TITLE]',
    icon: '[ICON]',
    description: '[DESCRIPTION]',
    details: {
        answer: '[DETAILED_ANSWER]',
        strategies: [
            '[STRATEGY_1]',
            '[STRATEGY_2]',
            '[STRATEGY_3]'
        ],
        resources: [
            { title: '[RESOURCE_TITLE]', url: '[URL]' }
        ],
        experts: []
    },
    tags: ['[TAG1]', '[TAG2]', '[TAG3]'],
    dateAdded: '[YYYY-MM-DD]',
    submittedBy: '[NAME or Anonymous]',
    isNew: true
}
```

---

## Step 3: Fill in the Details

### **id:** 
Next sequential number (if last resource is id: 8, use 9)

### **category:** 
Must be one of these exact values:
- `'workplace'`
- `'hiring'`
- `'leadership'`
- `'accessibility'`
- `'language'`
- `'policy'`

### **title:**
Copy from the Google Sheet submission

### **icon:**
Choose an appropriate emoji:
- 💬 Discussion/Communication
- 👥 People/Team
- 📋 Policy/Process
- ♿ Accessibility
- 🎯 Goals/Strategy
- 📚 Learning/Education
- 🤝 Collaboration
- ✉️ Email/Messages

### **description:**
Short summary (1-2 sentences from the submission)

### **details.answer:**
Main explanation or guidance

### **details.strategies:**
List of 3-5 bullet points with practical advice

### **details.resources:**
Links to external resources (if provided in submission)

### **tags:**
3-5 relevant keywords in lowercase

### **dateAdded:**
Today's date in format: `'2025-02-12'`

### **submittedBy:**
Name from Google Sheet or `'Anonymous'`

### **isNew:**
Set to `true` for new resources (shows "NEW" badge)

---

## Step 4: Add to the Code

1. **Download your current index.html** from GitHub
2. **Open in text editor** (VS Code, Notepad++, or even Notepad)
3. **Find the resources array** (search for `const resources = [`)
4. **Scroll to the last resource** (the one with the highest id number)
5. **After the closing }** add a comma
6. **Paste your new resource**
7. **Save the file**

---

## Example - Real Submission

**From Google Sheet:**
- Resource Type: Q&A
- Category: Workplace  
- Title: "How to handle pronouns in email signatures"
- Description: "Guidance on adding and respecting pronouns"
- Submitted By: Sarah K

**Code to add:**

```javascript
{
    id: 9,
    category: 'workplace',
    title: 'How to handle pronouns in email signatures',
    icon: '✉️',
    description: 'Guidance on adding and respecting pronouns in professional email signatures.',
    details: {
        answer: 'Including pronouns in email signatures helps create an inclusive environment and normalises the practice.',
        strategies: [
            'Add your pronouns to your signature (e.g., "Sarah Kennedy (she/her)")',
            'Never assume someone\'s pronouns based on their name or appearance',
            'If you see pronouns you haven\'t encountered before, respect them',
            'Make it optional - not everyone is comfortable sharing pronouns publicly',
            'Lead by example in senior positions'
        ],
        resources: [
            { title: 'Pronoun Usage Guide - GLEN', url: 'https://www.glen.ie' }
        ],
        experts: []
    },
    tags: ['pronouns', 'email', 'workplace', 'inclusion'],
    dateAdded: '2025-02-12',
    submittedBy: 'Sarah K',
    isNew: true
}
```

---

## Step 5: Upload to GitHub

### **If using GitHub website:**

1. Go to your repository on GitHub
2. Click on `index.html`
3. Click the **pencil icon** (Edit this file)
4. Delete the old content
5. Paste your updated code
6. Scroll to bottom
7. Add commit message: "Added new resource: [Title]"
8. Click **"Commit changes"**

### **If using drag-and-drop:**

1. Delete old `index.html` from repository
2. Upload your new `index.html`
3. Commit with message

---

## Step 6: Verify It's Live

1. Wait 1-2 minutes for GitHub Pages to update
2. Visit your Ripple site
3. Check the stats have updated (Resource count increased)
4. Search for your new resource
5. Click it to verify all details are correct

---

## Tips

### **Copy Existing Resources**
The easiest way is to copy an existing resource that's similar to your new one, then just change the details.

### **Check Your Commas**
JavaScript is picky about commas:
- Each resource needs a comma after the closing `}`
- Except the very last one
- Missing or extra commas will break the site

### **Test Before Publishing**
If you have a Mac, you can open the HTML file locally in a browser to test before uploading.

### **Keep Backups**
Before making changes, download a copy of your current working index.html as backup.

---

## Common Mistakes

❌ **Forgot to increase id number** → Resources clash  
❌ **Wrong category name** → Resource doesn't show in right filter  
❌ **Missing comma** → Site breaks  
❌ **Extra comma after last resource** → Site breaks  
❌ **Single quotes in text** → Use `\'` instead (e.g., `don\'t`)  
❌ **Forgot isNew: true** → No NEW badge shows  

---

## Updating the Stats

Good news! The stats (Resources, Contributors, Topics, Experts) now update **automatically**. 

When you add a new resource:
- Resource count increases
- If it's a new contributor, that count increases
- If it's in a new category, Topics increases
- If you add experts, that count increases

No manual updates needed! 🎉

---

## Questions?

If something breaks:
1. Check the browser console for errors (F12 in most browsers)
2. Look for the line number of the error
3. Usually it's a missing comma or quote
4. Restore your backup and try again

---

**You've got this!** Adding resources gets easier each time. 🌊
